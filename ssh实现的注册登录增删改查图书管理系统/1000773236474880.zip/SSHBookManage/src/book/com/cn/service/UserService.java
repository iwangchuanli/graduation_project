package book.com.cn.service;
import java.util.List;

import book.com.cn.bean.User;
public interface UserService {
	// �����û�
	public boolean addUser(User user);
	// ��¼
	public boolean check(User user);
	

}



