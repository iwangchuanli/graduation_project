package book.com.cn.service;
import java.util.List;

import book.com.cn.bean.User;
import book.com.cn.dao.UserDao;

public class UserServiceImpl implements UserService {
	private UserDao userDao; // DAO�������DAO�ӿڶ���

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	// �����û�
	public boolean addUser(User user) {
		if (userDao.queryByID(user.getId())==null)
			userDao.save(user);
		else
			return false;
		return true;
	}
	// �û���¼
	public boolean check(User user) {
		if (this.userDao.check(user)) {
			return true;
		} else {
			return false;
		}
	}





}
