package book.com.cn.service;

import java.util.List;

import book.com.cn.bean.Book;
import book.com.cn.dao.BookDao;
import book.com.cn.util.Page;

public class BookServiceImpl implements BookService {
	private BookDao bookDao; // DAO�������DAO�ӿڶ���

	public void setBookDao(BookDao bookDao) {
		this.bookDao = bookDao;
	}

	// ����ͼ��
	public boolean addBook(Book book) {
	if (bookDao.queryByID(book.getId()) == null)
			bookDao.save(book);
	else
			return false;
	return true;
	}

	// ɾ��ͼ��
	public boolean deleteBook(int id) {
		if (bookDao.queryByID(id) != null)
			bookDao.delete(id);
		else
			return false;
		return true;
	}

	// ����ͼ��
	public boolean updateBook(Book book) {
		if (bookDao.queryByID(book.getId()) != null)
			bookDao.update(book);
		else
			return false;
		return true;
	}

	// ��ѯ����ͼ��
	public List queryAllBook(String name) {
		return bookDao.queryAll(name);
	}

	// ��ѯָ��ҳͼ��
	public List queryPageBook(Page page) {
		return bookDao.queryPage(page);
	}

	// ��ID��ѯͼ��
	public Book queryBookByID(int id) {
		return bookDao.queryByID(id);
	}

	public BookDao getBookDao() {
		return bookDao;
	}

	


}

