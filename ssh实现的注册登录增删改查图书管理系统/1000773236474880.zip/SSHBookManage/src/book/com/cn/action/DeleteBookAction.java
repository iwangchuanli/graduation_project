package book.com.cn.action;
import book.com.cn.service.BookService;

import com.opensymphony.xwork2.ActionSupport;
public class DeleteBookAction extends ActionSupport {
	private int id;
	private BookService bookService; 
	// ҵ���߼��������,�ýӿڶ��壬�����ඨ��

	public void setBookService(BookService bookService) {
		this.bookService = bookService;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String execute() throws Exception {
		if (bookService.deleteBook(id))
			return SUCCESS;
		else
			return ERROR;
	}
}
