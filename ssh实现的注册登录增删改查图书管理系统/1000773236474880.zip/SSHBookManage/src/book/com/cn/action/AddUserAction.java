package book.com.cn.action;
import book.com.cn.bean.User;
import book.com.cn.service.UserService;

import com.opensymphony.xwork2.ActionSupport;
import java.util.Date;

import javax.swing.JOptionPane;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AddUserAction extends ActionSupport {
	private String username, password;
	private int id;
	private UserService userService; 
	// ҵ���߼��������,�ýӿڶ��壬�����ඨ��

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	public String execute() throws Exception {
		User user = new User();
		user.setId(id);
		user.setUsername(username);
		user.setPassword(password);
		if (userService.addUser(user))
			return SUCCESS;
		else
			return ERROR;
	}
}
