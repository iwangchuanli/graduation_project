package book.com.cn.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import book.com.cn.service.BookService;
import book.com.cn.util.Page;

import com.opensymphony.xwork2.ActionSupport;

public class ShowPageBookAction extends ActionSupport {
	private int pageIndex = 0;
	private Page page;

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public void setPage(Page page) {
		this.page = page;
	}

	private BookService bookService; 
	// ҵ���߼��������,�ýӿڶ��壬�����ඨ��

	public void setBookService(BookService bookService) {
		this.bookService = bookService;
	}

	public String execute() throws Exception {
		page.setPageIndex(pageIndex);
		List onePage = bookService.queryPageBook(page);
		ServletActionContext.getRequest().setAttribute("page", page);
		ServletActionContext.getRequest().setAttribute("onePage", onePage);
		return SUCCESS;
	}
}
