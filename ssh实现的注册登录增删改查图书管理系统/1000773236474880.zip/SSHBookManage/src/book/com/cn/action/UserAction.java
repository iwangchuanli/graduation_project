package book.com.cn.action;



import book.com.cn.bean.User;
import book.com.cn.service.UserService;

import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {
	private User user;
	private UserService userService;
	private String longinerror;
	public String getLonginerror() {
		return longinerror;
	}

	public void setLonginerror(String longinerror) {
		this.longinerror = longinerror;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public String login() {
		System.out.println(this.userService.check(this.user));
		if (this.userService.check(this.user)) {
			return SUCCESS;
		} else {
			longinerror="�û�������������󣡣�������";
			return INPUT;
		}
	}

}
