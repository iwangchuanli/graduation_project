package book.com.cn.action;

import book.com.cn.bean.Book;
import book.com.cn.bean.User;
import book.com.cn.service.BookService;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.ServletActionContext;

public class ShowBookAction extends ActionSupport {
	private int id;
	private BookService bookService;
	// ҵ���߼��������,�ýӿڶ��壬�����ඨ��

	public void setBookService(BookService bookService) {
		this.bookService = bookService;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public String execute() throws Exception {
		
		Book book =bookService.queryBookByID(id);
		ServletActionContext.getRequest().setAttribute("book", book);
		return SUCCESS;
	}
}