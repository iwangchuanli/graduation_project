package book.com.cn.action;

import book.com.cn.service.BookService;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.ServletActionContext;

import java.util.List;

public class ShowAllBookAction extends ActionSupport {
    private BookService bookService;
    // ҵ���߼��������,�ýӿڶ��壬�����ඨ��
    private String name;

    public BookService getBookService() {
        return bookService;
    }

    public void setBookService(BookService bookService) {
        this.bookService = bookService;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String execute() throws Exception {
        String _name = name;
        if (name != null) {
            _name = new String(name.getBytes("iso8859-1"), "gb2312");
        }
        List all = bookService.queryAllBook(_name);
        ServletActionContext.getRequest().setAttribute("all", all);
        return SUCCESS;
    }
}
