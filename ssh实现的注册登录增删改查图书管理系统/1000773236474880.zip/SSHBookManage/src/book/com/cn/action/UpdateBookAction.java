package book.com.cn.action;

import java.util.Date;

import book.com.cn.bean.Book;
import book.com.cn.service.BookService;

import com.opensymphony.xwork2.ActionSupport;

public class UpdateBookAction extends ActionSupport {
	private String name, author, publisher;
	
	private int id;
	private BookService bookService; 
	// ҵ���߼�����������ýӿڶ��壬�����ඨ��
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	

	public String execute() throws Exception {
		Book book = new Book();
		book.setId(id);
		book.setName(name);
		book.setAuthor(author);
		book.setPublisher(publisher);
		if (bookService.updateBook(book))
			return SUCCESS;
		else
			return ERROR;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public BookService getBookService() {
		return bookService;
	}

	public void setBookService(BookService bookService) {
		this.bookService = bookService;
	}
}

