package book.com.cn.dao;
import java.sql.SQLException;
import java.util.List;
import org.hibernate.*;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.orm.hibernate3.HibernateCallback;
import book.com.cn.bean.User;
import book.com.cn.util.Page;


public class UserDaoImpl extends HibernateDaoSupport implements UserDao,
		HibernateCallback {
	Page page;// �����ҳ����
	// �����û�
	public void save(User user) {
		this.getHibernateTemplate().save(user);

	}
	public boolean check(User user) {
        if(user!=null){
            String hql="from book.com.cn.bean.User where username='"+user.getUsername()+"' and password='"+user.getPassword()+"'";
            
            
            List<User> list=this.getHibernateTemplate().find(hql);
            if(!list.isEmpty()){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
	// ��ID��ѯ�û�
	public User queryByID(int id) {
		return (User) this.getHibernateTemplate().get(User.class, id);
	}
	public Object doInHibernate(Session arg0) throws HibernateException,
			SQLException {
	
		return null;
	}







}
