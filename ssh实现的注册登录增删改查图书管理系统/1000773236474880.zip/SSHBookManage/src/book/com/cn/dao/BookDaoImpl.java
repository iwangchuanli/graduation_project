package book.com.cn.dao;
import java.util.List;
import java.sql.SQLException;
import org.hibernate.*;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.orm.hibernate3.HibernateCallback;

import book.com.cn.bean.Book;
import book.com.cn.util.Page;
public class BookDaoImpl extends HibernateDaoSupport implements BookDao,
			HibernateCallback {
		Page page;// �����ҳ����
		// ����ͼ��
		public void save(Book book) {
			this.getHibernateTemplate().save(book);

		}
		// ɾ��ͼ��
		public void delete(int id) {
			Book book = new Book();
			book.setId(id);
			this.getHibernateTemplate().delete(book);
		}
		// ����ͼ��
		public void update(Book book) {
			this.getHibernateTemplate().update(book);
		}
		// ��ѯ����ͼ��
		public List queryAll(String name) {
			if(name==null){
			return getHibernateTemplate().find("from book.com.cn.bean.Book");
			}else{
				String sql="from book.com.cn.bean.Book where name like '%"+name+"%'";  
				return getHibernateTemplate().find("from book.com.cn.bean.Book where name like '%"+name+"%'");
	 	        }
		}

		// ��ҳ��ѯͼ��
		public List queryPage(Page page) {
			this.page = page;
			return getHibernateTemplate().executeFind(this);
		}

		// ��ID��ѯͼ��
		public Book queryByID(int id) {
			return (Book)this.getHibernateTemplate().get(Book.class, id);
		}

		// ��дHibernateCallback�ӿ��е�doInHibernate������ʵ�ַ�ҳ��ѯͼ��
		public Object doInHibernate(Session session) throws HibernateException,
				SQLException {
			
			List list = session.createSQLQuery("select count(*) from book").list();
			int bCount = ((java.math.BigInteger) list.get(0)).intValue();
			page.setRowCount(bCount); // �õ���¼����
			int pageRow = page.getPageRow();
			Query query = session.createQuery("from Book");
			query.setFirstResult(page.getPageIndex() * pageRow);
			query.setMaxResults(pageRow); // ÿҳ��¼��
			return query.list();
		}
		

	}
