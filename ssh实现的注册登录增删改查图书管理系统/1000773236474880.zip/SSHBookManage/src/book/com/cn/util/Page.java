package book.com.cn.util;
public class Page{
    public Page(){}
    public Page(int pageIndex){this.pageIndex=pageIndex;}
    int pageIndex=0;         //��ǰҳ��
    int pageRow=2;           //ÿҳ����
    int rowCount=1;          //������
    String direct="showPageUser?pageIndex=";         //�����ַ
    public void setDirect(String direct) {this.direct=direct;}
    public int getRowCount() {return rowCount;}
    public void setRowCount(int rowCount) {this.rowCount=rowCount; }
    public int getPageRow() {return pageRow;}
    public void setPageRow(int pageRow) {this.pageRow=pageRow;}
    public int getFirstPage() {return 0;}
    public int getPrvePage() {return pageIndex>0?pageIndex-1:0;}
    public int getPageIndex() {return pageIndex;}
    public void setPageIndex(int pageIndex) {this.pageIndex=pageIndex;}
    public int getPageCount() {return getLastPage()+1;} 
    public int getNextPage() {return pageIndex<getLastPage()?pageIndex+1:getLastPage();}
    public int getLastPage() {return (rowCount+pageRow-1)/pageRow-1;}

    public String getPageStr() {
        String str="";
        if (pageIndex>0){
            str="<a href='"+direct+getFirstPage()+"'>��ҳ</a> ";
            str+="<a href='"+direct+getPrvePage()+"'>��һҳ</a> ";
        } else 
            str+="��ҳ ��һҳ ";
        str+="��"+(1+pageIndex)+"ҳ����"+getPageCount()+"ҳ�����м�¼"+rowCount+"�� ";
        if (pageIndex+1<getPageCount()){ 
            str+="<a href='"+direct+getNextPage()+"'>��һҳ</a> ";
            str+="<a href='"+direct+getLastPage()+"'>βҳ</a>";
        }else
            str+="��һҳ βҳ ";
        return str;
    }
}

