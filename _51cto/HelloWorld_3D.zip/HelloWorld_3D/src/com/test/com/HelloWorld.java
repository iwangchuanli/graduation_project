package com.test.com;

import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;

import org.lwjgl.input.Mouse;


import com.threed.jpct.Camera;
import com.threed.jpct.FrameBuffer;
import com.threed.jpct.IRenderer;
import com.threed.jpct.Loader;
import com.threed.jpct.Matrix;
import com.threed.jpct.Object3D;
import com.threed.jpct.SimpleVector;
import com.threed.jpct.Texture;
import com.threed.jpct.TextureManager;
import com.threed.jpct.World;
import com.threed.jpct.util.KeyMapper;
import com.threed.jpct.util.KeyState;

public class HelloWorld {



	private World world;
	private FrameBuffer buffer;
	private Object3D[] scene;
	private Object3D[] teemo;
	
	private Object3D[] demacia;
	private KeyMapper keyMapper = null;
	private MouseMapper mouseMapper = null;
	boolean doLoop=true;
	private Ticker ticker = new Ticker(15);
	private Camera camera;
	
	public static String resource_root_path="./resource/";
	
	
	
	boolean s=true;
	public static void main(String[] args) throws Exception {
		new HelloWorld().loop();
	}

	public HelloWorld() throws Exception {
		world = new World();
		world.setAmbientLight(240, 240, 240);
	
		
		buffer = new FrameBuffer(800, 600, FrameBuffer.SAMPLINGMODE_NORMAL);
		buffer.disableRenderer(IRenderer.RENDERER_SOFTWARE);
		buffer.enableRenderer(IRenderer.RENDERER_OPENGL);
		org.lwjgl.opengl.Display.setTitle("HelloWorld_3D");
		keyMapper=new KeyMapper();
		mouseMapper = new MouseMapper(buffer);
		mouseMapper.hide();
		
		TextureManager.getInstance().addTexture("dome", new Texture(resource_root_path+"sky/dome_0.jpg"));
		TextureManager.getInstance().addTexture("grass", new Texture(resource_root_path+"sky/tile.jpg"));
		TextureManager.getInstance().addTexture("wall", new Texture(resource_root_path+"sky/wall_3.jpg"));
		TextureManager.getInstance().addTexture("tk", new Texture(resource_root_path+"sky/tk.jpg"));
		TextureManager.getInstance().addTexture("teemo", new Texture(resource_root_path+"teemo_astronaut_TX_CM.jpg"));
		
		TextureManager.getInstance().addTexture("00bOOOPICbe_1024", new Texture(resource_root_path+"sky/00bOOOPICbe_1024.jpg"));
		TextureManager.getInstance().addTexture("84bOOOPIC98_1024", new Texture(resource_root_path+"sky/84bOOOPIC98_1024.jpg"));
		
		scene =Loader.load3DS(resource_root_path+"sky/scene.3DS", 1);
		teemo =Loader.load3DS(resource_root_path+"teemo.3DS", 1);
		demacia=Loader.load3DS(resource_root_path+"Demacia.3DS", 1);
		TextureManager.getInstance().addTexture("Garen", new Texture(resource_root_path+"Garen_base_low_TX_CM.jpg"));
		TextureManager.getInstance().addTexture("jarvanIV", new Texture(resource_root_path+"jarvanIV_base_TX_CM.jpg"));
		TextureManager.getInstance().addTexture("Xinzhao", new Texture(resource_root_path+"Xinzhao_zhaoyun_TX_CM.jpg"));
		
		demacia[0].setTexture("Garen");
		demacia[1].setTexture("jarvanIV");
		demacia[2].setTexture("Xinzhao");
		
		teemo[0].setTexture("teemo");
		//scene[0].build();
		
		
		scene[0].setCulling(Object3D.CULLING_DISABLED);
		scene[0].setTexture("dome");
		//scene[0].build();
		
		scene[1].invert();
		scene[1].setTexture("wall");
		scene[1].setCollisionMode(Object3D.COLLISION_CHECK_OTHERS);
		//scene[1].build();
		
		
		scene[2].invert();
		scene[2].setTexture("grass");
		scene[2].setCollisionMode(Object3D.COLLISION_CHECK_OTHERS);
		//scene[2].build();
		
		
		scene[3].setTexture("tk");
		scene[3].setCollisionMode(Object3D.COLLISION_CHECK_OTHERS);
		scene[3].setTransparency(0);
		scene[3].setTransparencyMode(Object3D.TRANSPARENCY_MODE_ADD);
		//scene[3].build();
		scene[4].setTexture("84bOOOPIC98_1024");
		
		
		world.addObjects(scene);
		world.addObjects(teemo);
		world.addObjects(demacia);
		
		camera=world.getCamera();
		camera.setPosition(-200, -75, -200);
		camera.lookAt(new SimpleVector(-200,-75, -199));
	}
	
	
	private void loop() throws Exception {
		
		long ticks = 0;
		
		long last=System.currentTimeMillis();
		while (doLoop) {
			
			ticks = ticker.getTicks();
			if (ticks > 0) {
				pollControls();
				move(ticks);
			}
			
		
			long current= System.currentTimeMillis();
			
			if(current-last>3000){
				last=current;
				s=!s;
				if(s){
					scene[4].setTexture("84bOOOPIC98_1024");
				}else {
					scene[4].setTexture("00bOOOPICbe_1024");
				}
			}
			
			scene[0].rotateY(0.0002f);
			buffer.clear(java.awt.Color.BLUE);
			world.renderScene(buffer);
			world.draw(buffer);
			buffer.update();
			buffer.displayGLOnly();
			Thread.sleep(15);
		}
		buffer.disableRenderer(IRenderer.RENDERER_OPENGL);
		buffer.dispose();
		System.exit(0);
	}

	
	private boolean forward = false;
	private boolean backward = false;
	private boolean up = false;
	private boolean down = false;
	private boolean left = false;
	private boolean right = false;
	private float xAngle = 0;
	
	private void pollControls() {

		KeyState ks = null;
		
		while ((ks = keyMapper.poll()) != KeyState.NONE) {
			if (ks.getKeyCode() == KeyEvent.VK_ESCAPE) {
				doLoop = false;
			}
			
			
			if (ks.getKeyCode() == KeyEvent.VK_UP||ks.getKeyCode() == KeyEvent.VK_W) {
				forward = ks.getState();
			}

			if (ks.getKeyCode() == KeyEvent.VK_DOWN||ks.getKeyCode() == KeyEvent.VK_S) {
				backward = ks.getState();
			}

			if (ks.getKeyCode() == KeyEvent.VK_LEFT||ks.getKeyCode() == KeyEvent.VK_A) {
				left = ks.getState();
			}

			if (ks.getKeyCode() == KeyEvent.VK_RIGHT||ks.getKeyCode() == KeyEvent.VK_D) {
				right = ks.getState();
			}

			if (ks.getKeyCode() == KeyEvent.VK_PAGE_UP||ks.getKeyCode() == KeyEvent.VK_SPACE) {
				up = ks.getState();
			}

			if (ks.getKeyCode() == KeyEvent.VK_PAGE_DOWN||ks.getKeyCode() == KeyEvent.VK_CONTROL) {
				down = ks.getState();
			}
		}

		if (org.lwjgl.opengl.Display.isCloseRequested()) {
			doLoop = false;
		}
	}
	
	private void move(long ticks) {

		if (ticks == 0) {
			return;
		}
		
		
		float speed=ticks;
		SimpleVector ellipsoid = new SimpleVector(5, 5, 5);
		
		// Key controls
		
		if (forward) {
			world.checkCameraCollisionEllipsoid(Camera.CAMERA_MOVEIN,
					ellipsoid, speed, 5);
		}

		if (backward) {
			world.checkCameraCollisionEllipsoid(Camera.CAMERA_MOVEOUT,
					ellipsoid, speed, 5);
		}

		if (left) {
			world.checkCameraCollisionEllipsoid(Camera.CAMERA_MOVELEFT,
					ellipsoid, speed, 5);
		}

		if (right) {
			world.checkCameraCollisionEllipsoid(Camera.CAMERA_MOVERIGHT,
					ellipsoid, speed, 5);
		}

		if (up) {
			world.checkCameraCollisionEllipsoid(Camera.CAMERA_MOVEUP,
					ellipsoid, speed, 5);
		}

		if (down) {
			world.checkCameraCollisionEllipsoid(Camera.CAMERA_MOVEDOWN,
					ellipsoid, speed, 5);
		}

		// mouse rotation

		Matrix rot =camera.getBack();
		int dx = mouseMapper.getDeltaX();
		int dy = mouseMapper.getDeltaY();

		float ts = 0.2f * ticks;
		float tsy = ts;

		if (dx != 0) {
			ts = dx / 500f;
		}
		if (dy != 0) {
			tsy = dy / 500f;
		}

		if (dx != 0) {
			rot.rotateAxis(rot.getYAxis(), ts);
		}

		if ((dy > 0 && xAngle < Math.PI / 4.2)
				|| (dy < 0 && xAngle > -Math.PI / 4.2)) {
			rot.rotateX(tsy);
			xAngle += tsy;
		}

		

		
	}
	private static class MouseMapper {

		private boolean hidden = false;

		private int height = 0;

		public MouseMapper(FrameBuffer buffer) {
			height = buffer.getOutputHeight();
			init();
		}

		public void hide() {
			if (!hidden) {
				Mouse.setGrabbed(true);
				hidden = true;
			}
		}

		public void show() {
			if (hidden) {
				Mouse.setGrabbed(false);
				hidden = false;
			}
		}

		public boolean isVisible() {
			return !hidden;
		}

		public void destroy() {
			show();
			if (Mouse.isCreated()) {
				Mouse.destroy();
			}
		}

		public boolean buttonDown(int button) {
			return Mouse.isButtonDown(button);
		}

		public int getMouseX() {
			return Mouse.getX();
		}

		public int getMouseY() {
			return height - Mouse.getY();
		}

		public int getDeltaX() {
			if (Mouse.isGrabbed()) {
				return Mouse.getDX();
			} else {
				return 0;
			}
		}

		public int getDeltaY() {
			if (Mouse.isGrabbed()) {
				return Mouse.getDY();
			} else {
				return 0;
			}
		}

		private void init() {
			try {
				if (!Mouse.isCreated()) {
					Mouse.create();
				}

			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}
	private static class Ticker {

		private int rate;
		private long s2;

		public static long getTime() {
			return System.currentTimeMillis();
		}

		public Ticker(int tickrateMS) {
			rate = tickrateMS;
			s2 = Ticker.getTime();
		}

		public int getTicks() {
			long i = Ticker.getTime();
			if (i - s2 > rate) {
				int ticks = (int) ((i - s2) / (long) rate);
				s2 += (long) rate * ticks;
				return ticks;
			}
			return 0;
		}
	}
	
	
}
